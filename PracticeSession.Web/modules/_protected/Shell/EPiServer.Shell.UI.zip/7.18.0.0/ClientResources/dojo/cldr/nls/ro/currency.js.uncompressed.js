define(
"dojo/cldr/nls/ro/currency", //begin v1.x content
{
	"HKD_displayName": "dolar Hong Kong",
	"CHF_displayName": "franc elvețian",
	"CAD_displayName": "dolar canadian",
	"CNY_displayName": "yuan renminbi chinezesc",
	"USD_symbol": "$",
	"AUD_displayName": "dolar australian",
	"JPY_displayName": "yen japonez",
	"USD_displayName": "dolar american",
	"GBP_displayName": "liră sterlină",
	"EUR_displayName": "euro"
}
//end v1.x content
);