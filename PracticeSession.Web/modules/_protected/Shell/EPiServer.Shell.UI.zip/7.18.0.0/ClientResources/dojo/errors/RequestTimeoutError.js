//>>built
define("dojo/errors/RequestTimeoutError",["./create","./RequestError"],function(_1,_2){return _1("RequestTimeoutError",null,_2,{dojoType:"timeout"});});