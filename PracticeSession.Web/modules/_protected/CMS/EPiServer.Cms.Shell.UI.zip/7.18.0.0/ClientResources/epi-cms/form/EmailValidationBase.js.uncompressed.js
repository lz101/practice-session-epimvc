﻿define("epi-cms/form/EmailValidationBase", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojox/validate/web",
    "dijit/form/ValidationTextBox",
    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.form.emailvalidation"
], function (
    declare,
    lang,
    validator,
    ValidationTextBox,
// Resources
    resources
    ) {

    return declare([ValidationTextBox], {
        // summary:
        //    Represents the email input textbox.
        // tags:
        //    internal

        validator: function (value, constraints) {
            // summary:
            //		Validate the text input with email address validation.
            // tags:
            //		overrided
            return (!this.required && this._isEmpty(value)) || (validator.isEmailAddress(value, constraints)); // Boolean
        },              

        invalidMessage: resources.invalidmessage

    });
});